package ast;

import compile.SymbolTable;

import java.util.List;

public class TypeArray extends Type{
    private final Type type; //int_type
    private final int size; // number of dimensions
    public TypeArray(Type type, int size){
        this.size = size;
        this.type = type;

    }



    public Type getType() {
        return type;
    }

    public int getSize() {
        return size;
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) { return visitor.visit(this); }
}
