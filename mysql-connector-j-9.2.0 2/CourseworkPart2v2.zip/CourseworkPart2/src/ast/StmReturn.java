package ast;

import compile.SymbolTable;

public class StmReturn extends Stm {
    public final Exp expression;

    public StmReturn(Exp expression) {
        this.expression = expression;
    }

    @Override
    public void compile(SymbolTable st) {
        if (expression != null) {
            expression.compile(st); // Push return value
            int localCount = st.inMethodScope ? st.locals.size() : 0;
            emit("push " + localCount); // Push n (params + locals)
            emit("ret");
        } else {
            emit("push 0");
            emit("ret");
        }
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}