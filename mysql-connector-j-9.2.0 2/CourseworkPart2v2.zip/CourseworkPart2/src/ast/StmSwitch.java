package ast;

import compile.StaticAnalysisException;
import compile.SymbolTable;

import java.util.*;

public class StmSwitch extends Stm {

    public final Exp caseExp;
    public final Stm defaultCase;
    public final List<Case> cases;

    public StmSwitch(Exp caseExp, Stm defaultCase, List<Case> cases) {
        this.caseExp = caseExp;
        this.defaultCase = defaultCase;
        this.cases = cases;
    }

    @Override
    public void compile(SymbolTable st) {
        String defLabel = st.freshLabel("default");
        String endLabel = st.freshLabel("end");
        Map<Integer, String> caseLabels = new HashMap<>();

        for (Case c : cases) {
            //for here there was no way to identify the minus "-" as a token, so I used the 'negative' keyword to show it.
            String caseLabel = st.freshLabel("case" + (c.caseNumber < 0 ? "negative" + (-c.caseNumber) : c.caseNumber));
            caseLabels.put(c.caseNumber, caseLabel);
        }

        caseExp.compile(st);
        //duplicating the case value, so it can be compared for each case number it needs to go to.
        for (Case c : cases) {
            emit("dup");
            emit("push " + c.caseNumber);
            emit("sub");
            emit("jumpi_z " + caseLabels.get(c.caseNumber));
        }
        // pop the value and jump to the default case if no case value has been matched.
        emit("pop");
        emit("jumpi " + defLabel);

        for (Case c : cases) {
            emit(caseLabels.get(c.caseNumber) + ":");
            c.stm.compile(st);
            emit("jumpi " + endLabel);
        }
        emit(defLabel + ":");
        defaultCase.compile(st);

        emit(endLabel + ":");
    }

    public static class Case {

        public final int caseNumber;
        public final Stm stm;

        public Case(int caseNumber, Stm stm) {
            this.caseNumber = caseNumber;
            this.stm = stm;
        }
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) { return visitor.visit(this); }

}
