package ast.util;

import ast.*;

public interface Visitor<T> {

    T visit(ExpTimes expTimes);

    T visit(ExpPlus expPlus);

    T visit(ExpMinus expMinus);

    T visit(ExpDiv expDiv);

    T visit(ExpLessThan expLessThan);

    T visit(ExpLessThanEqual expLessThanEqual);

    T visit(ExpEqual expEqual);

    T visit(ExpAnd expAnd);

    T visit(ExpOr expOr);

    T visit(ExpInt expInt);

    T visit(ExpNot expNot);

    T visit(ExpVar expVar);

    T visit(Program program);

    T visit(StmAssign stmAssign);


    T visit(StmBlock stmBlock);

    T visit(StmIf stmIf);

    T visit(StmNewline stmNewline);

    T visit(StmPrint stmPrint);

    T visit(StmPrintChar stmPrintChar);

    T visit(StmPrintln stmPrintln);

    T visit(StmSwitch stmSwitch);

    T visit(StmWhile stmWhile);




    T visit(MethodDef methodDef);

    T visit(StmMethodCall stmMethodCall);
    T visit(StmAssignVar stmAssignVar);

    T visit(StmReturn stmReturn);

    T visit(ExpFunCall expFunCall);

    T visit(StmAssignArray stmAssignArray);

    T visit(ExpArrayLength expArrayLength);

    T visit(ExpNull expNull);


    T visit(TypeArray typeArray);

    T visit(ExpNewArray expNewArray );

    T visit(ExpAccessArray expAccessArray);


    T visit(Type type);

    T visit(TypeInt typeInt);

    T visit(VarDecl varDecl);
}
