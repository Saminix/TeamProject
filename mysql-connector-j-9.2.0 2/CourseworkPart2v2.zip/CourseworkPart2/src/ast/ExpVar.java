package ast;

import compile.SymbolTable;

import java.util.List;

public class ExpVar extends Exp {
    public final String varName;

    public ExpVar(String varName) {
        this.varName = varName;
    }

    @Override
    public void compile(SymbolTable st) {
        List<String> addressInstructions = st.lookupVarAddress(varName);
        for (String instr : addressInstructions) {
            emit(instr);
        }
        emit("load");
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}