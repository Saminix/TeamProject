package ast;

import compile.StaticAnalysisException;

public abstract class Type extends AST {}
