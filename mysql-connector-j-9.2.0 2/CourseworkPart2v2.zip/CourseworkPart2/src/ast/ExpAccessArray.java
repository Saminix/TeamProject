package ast;

import compile.SymbolTable;

import java.util.List;

public class ExpAccessArray extends Exp {
    private final String id;
    private final List<Exp> indexes;

    public ExpAccessArray(String id, List<Exp> indexes) {
        this.id = id;
        this.indexes = indexes;
    }

    @Override
    public void compile(SymbolTable st) {
        Type type = st.getVarType(id);
        if (!(type instanceof TypeArray)) {
            throw new RuntimeException("Variable " + id + " is not an array");
        }
        if (indexes.size() > ((TypeArray) type).getSize()) {
            throw new RuntimeException("Too many indices for array " + id);
        }
        List<String> addressInstructions = st.lookupVarAddress(id);
        for (String instr : addressInstructions) {
            emit(instr);
        }
        emit("load");
        for (Exp index : indexes) {
            index.compile(st);
            emit("push 4");
            emit("mul");
            emit("add");
        }
        emit("load");
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}