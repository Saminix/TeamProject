package ast;

import compile.SymbolTable;

import java.util.List;

public class MethodDef extends Stm {
    public final boolean isFunction;
    public final Type returnType;
    public final String name;
    public final List<VarDecl> formals;
    private final List<VarDecl> locals;
    private final List<Stm> body;

    public MethodDef(boolean isFunction, Type returnType, String name,
                     List<VarDecl> formals, List<VarDecl> locals, List<Stm> body) {
        this.isFunction = isFunction;
        this.returnType = returnType;
        this.name = name;
        this.formals = formals;
        this.locals = locals;
        this.body = body;
    }

    @Override
    public void compile(SymbolTable st) {
        String label = "$_" + name;
        emit(label + ":");
        st.enterMethodScope(formals);
        if (!locals.isEmpty()) {
            emit("salloc " + locals.size());
            for (VarDecl local : locals) {
                st.addLocal(local.name, local.type);
            }
        }
        for (Stm stm : body) {
            stm.compile(st);
        }
        if (!endsWithReturn(body)) {
            if (isFunction) {
                emit("push 0");
            }
            emit("ret");
        }
        st.exitMethodScope();
    }

    private boolean endsWithReturn(List<Stm> body) {
        return !body.isEmpty() && body.get(body.size() - 1) instanceof StmReturn;
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}