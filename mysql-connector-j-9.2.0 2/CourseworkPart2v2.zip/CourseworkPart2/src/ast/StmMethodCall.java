package ast;

import compile.SymbolTable;

import java.util.List;

public class StmMethodCall extends Stm {
    public final List<Exp> actuals;
    public final String id;

    public StmMethodCall(String id, List<Exp> actuals) {
        this.actuals = actuals;
        this.id = id;
    }

    @Override
    public void compile(SymbolTable st) {
        SymbolTable.MethodEntry method = st.lookupMethod(id);
        if (method == null) {
            throw new RuntimeException("Undefined method: " + id);
        }
        if (method.getParamCount() != actuals.size()) {
            throw new RuntimeException("Method " + id + " expects " + method.getParamCount() + " parameters but got " + actuals.size());
        }
        for (Exp arg : actuals) {
            arg.compile(st);
        }
        emit("push " + actuals.size());
        emit("calli " + method.getLabel());
        if (!method.isFunction()) {
            emit("pop");
        }
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}