package ast;

import compile.SymbolTable;

import java.util.List;

public class ExpArrayLength extends Exp {
    private final String id;

    public ExpArrayLength(String id) {
        this.id = id;
    }

    @Override
    public void compile(SymbolTable st) {
        Type type = st.getVarType(id);
        if (!(type instanceof TypeArray)) {
            throw new RuntimeException("Variable " + id + " is not an array");
        }
        List<String> addressInstructions = st.lookupVarAddress(id);
        for (String instr : addressInstructions) {
            emit(instr);
        }
        emit("load");
        emit("load");
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}