package ast;

import compile.SymbolTable;

public class ExpNewArray extends Exp {
    private final Type type;
    private final Exp size;
    private final int totalDims;

    public ExpNewArray(Type type, Exp size, int totalDims) {
        this.totalDims = totalDims;
        this.size = size;
        this.type = type;
    }

    @Override
    public void compile(SymbolTable st) {
        if (!(type instanceof TypeInt)) {
            throw new RuntimeException("Only int arrays supported");
        }
        if (totalDims > 1) {
            throw new RuntimeException("Multi-dimensional arrays not yet supported");
        }

        // Compile size expression
        size.compile(st);              // Push size onto stack

        // Calculate total bytes (length + elements)
        emit("dup");                   // Duplicate size
        emit("push 4");                // 4 bytes per element
        emit("mul");                   // size * 4
        emit("push 4");                // 4 bytes for length
        emit("add");                   // Total bytes = 4 + size * 4

        // Get current heap pointer
        emit("push $heap_ptr");        // Address of heap pointer
        emit("load");                  // Load current heap pointer value
        emit("dup");                   // Save base address for result

        // Update heap pointer
        emit("swap");                  // Stack: ..., base, total_bytes
        emit("add");                   // New heap pointer = base + total_bytes
        emit("push $heap_ptr");        // Address of heap pointer
        emit("store");                 // Store new heap pointer

        // Store array length at base address
        emit("dup");                   // Duplicate base address
        emit("swap");                  // Stack: ..., base, size, base
        emit("store");                 // Store size at base[0]

        // Base address remains on stack as result
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}