package parse;

import ast.*;
import jdk.dynalink.Operation;
import sbnf.ParseException;
import sbnf.lex.Lexer;

import java.io.IOException;
import java.lang.annotation.Retention;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/** Parse an LPL program and build its AST.  */
public class LPLParser {

    /**
     * File path for the LPL SBNF file.
     * Note: this is a relative path so at runtime the working directory must
     * be the parent directory of this path (ie the root folder
     * of the project) or the file will not be found.
     */
    public static final String LPL_SBNF_FILE = "data/LPL.sbnf";

    private Lexer lex;

    /**
     * Initialise a new LPL parser.
     */
    public LPLParser() {
        lex = new Lexer(LPL_SBNF_FILE);
    }

    /** Parse an LPL source file and return its AST.
     *
     * @param sourcePath a path to an LPL source file
     * @return the AST for the parsed LPL program
     * @throws ParseException if the source file contains syntax errors
     * @throws IOException
     */
    public Program parse(String sourcePath) throws IOException {
        lex.readFile(sourcePath);
        lex.next();
        Program prog = Program();
        if (!lex.tok().isType("EOF")) {
            //System.out.println("Parsing token: " + lex.tok().type); debugging
            throw new ParseException(lex.tok(), "EOF");
        }
        return prog;
    }

    //Program -> BEGIN GlobalVarDecl* Stm* END
    private Program Program() {
        List<VarDecl> globals = new LinkedList<>();
        List<Stm> body = new LinkedList<>();
        List<MethodDef> methods = new LinkedList<>();

        lex.eat("BEGIN");

        globals = NonFormalVarDecls();
        while (!lex.tok().isType("END")) {
            body.add(Stm());
        }
        lex.eat("END");
        while (lex.tok().isType("FUN") || lex.tok().isType("PROC")) {
            methods.add(FunOrProcDef());
        }

        Program prog = new Program(globals, body); // Original signature
        Program.setMethods(methods); // Store methods separately
        return prog;
    }

    //GlobalVarDecl -> Type ID SEMIC
    private List<VarDecl> GlobalVarDecls() {
        List<VarDecl> globals = new LinkedList<>();
        while (lex.tok().isType("INT_TYPE")) {
            Type type = Type();
            String id = lex.tok().image;
            lex.eat("ID");
            lex.eat("SEMIC");
            globals.add(new VarDecl(type, id));
        }
        return globals;
    }

    //Type -> INT_TYPE
    // add for array type []
    private Type Type(){
        if(lex.tok().isType("INT_TYPE")){
            lex.next();
            int dimensions = 0;
            while(lex.tok().isType("LSQBR")){
                lex.eat("LSQBR");
                lex.eat("RSQBR");
                dimensions++;
            }
            if(dimensions == 0){
                return new TypeInt();
            } else{
                return new TypeArray(new TypeInt(), dimensions);
            }
        } else{
            throw new ParseException(lex.tok(), "INT_TYPE");
        }
    }

    //Case -> CASE OptionalSign INTLIT COLON Stm
    private StmSwitch.Case Case(){
        lex.eat("CASE");
        int sign = OptionalSign();
        if (!lex.tok().isType("INTLIT")) {
            throw new ParseException(lex.tok(), "INTLIT");
        }
        int caseValue = sign * Integer.parseInt(lex.tok().image);
        lex.next();
        lex.eat("COLON");
        Stm stm = Stm();
        return new StmSwitch.Case(caseValue, stm);
    }

    private Exp SimpleExp() {

        switch (lex.tok().type) {

            case "ID": {
                String id = lex.tok().image;  // Capture ID before advancing
                lex.next();
                return SimpleIDFactor(id);   // Handle function calls, array access, etc.

            }
            case "NEW": {
                lex.next();
                return NewArrayExp();
                }

            case "INTLIT": {
                int sign = OptionalSign();
                String intLit = lex.tok().image;
                lex.next();
                return new ExpInt(sign * Integer.parseInt(intLit));
            }
            case "NOT": {
                lex.next();
                Exp e = SimpleExp();
                return new ExpNot(e);
            }
            case "LBR": {
                lex.next();
                Exp e = Exp();
                lex.eat("RBR");
                return e;
            }
            case "MINUS": {
                lex.next();
                if (lex.tok().isType("INTLIT")) {
                    String intLit = lex.tok().image;
                    lex.next();
                    return new ExpInt(-1 * Integer.parseInt(intLit));
                } else {
                    throw new ParseException(lex.tok(), "INTLIT");
                }
            }
            case "NULL": {
                lex.next();
                return new ExpNull();
            }
            default:
                throw new ParseException(lex.tok(), "ID", "INTLIT", "NOT", "LBR", "MINUS", "NEW", "NULL");
        }
    }
    private int OptionalSign() {
        int sign = 1;
        while (lex.tok().isType("MINUS")) {
            lex.next();
            sign *= -1;
        }
        return sign;
    }
    //check the operator type : Operator
    private boolean isOperatorType(String token) {
        return token.equals("MUL") ||
                token.equals("DIV") ||
                token.equals("MINUS") ||
                token.equals("ADD") ||
                token.equals("LT") ||
                token.equals("LE") ||
                token.equals("EQ") ||
                token.equals("AND") ||
                token.equals("OR");
    }

    //OperatorClause -> Operator SimpleExp
//OperatorClause ->
    private Exp OperatorClause(Exp e1) {
        if (isOperatorType(lex.tok().type)) {
            String operatorType = lex.tok().type;
            lex.next();
            Exp e2 = SimpleExp();
            //use switch statement to check operator types
            switch (operatorType) {
                case "OR":
                    return new ExpOr(e1, e2);
                case "AND":
                    return new ExpAnd(e1, e2);
                case "MUL":
                    return new ExpTimes(e1, e2);
                case "DIV":
                    return new ExpDiv(e1, e2);
                case "MINUS":
                    return new ExpMinus(e1, e2);
                case "ADD":
                    return new ExpPlus(e1, e2);
                case "LT":
                    return new ExpLessThan(e1, e2);
                case "LE":
                    return new ExpLessThanEqual(e1, e2);
                case "EQ":
                    return new ExpEqual(e1, e2);
                default:
                    throw new ParseException(lex.tok(), "Unsupported operator" + operatorType);
            }
        }
        return e1;
    }

    //Exp -> SimpleExp OperatorClause
    private Exp Exp() {
        Exp e1 = SimpleExp();
        return OperatorClause(e1);
    }
    private Stm Stm() {
        switch (lex.tok().type) {

            case "LCBR": {
                lex.next();
                List<Stm> blockBody = new ArrayList<>();
                while (!lex.tok().isType("RCBR")) {
                    if (lex.tok().isType("END")) {
                        throw new ParseException(lex.tok(), "Unexpected END. Missing '}' ");
                    }
                    blockBody.add(Stm());
                }
                lex.eat("RCBR");
                return new StmBlock(blockBody);
            }
            case "ID": {
                String id = lex.eat("ID");
                    return StmIdFactor(id);
                }

            case "RETURN": {
                lex.next();
                return StmReturnFactor();

            }
            case "IF": {
                lex.next();
                lex.eat("LBR");
                Exp e = Exp();
                lex.eat("RBR");
                Stm branch = Stm();
                lex.eat("ELSE");
                Stm falseBran = Stm();
                return new StmIf(e, branch, falseBran);
            }
            case "WHILE": {
                lex.next();
                lex.eat("LBR");
                Exp e = Exp();
                lex.eat("RBR");
                Stm block = Stm();
                return new StmWhile(e, block);
            }
            case "PRINT": {
                lex.next();
                Exp e = Exp();
                lex.eat("SEMIC");
                return new StmPrint(e);
            }

            case "PRINTLN": {
                lex.next();
                Exp e = Exp();
                lex.eat("SEMIC");
                return new StmPrintln(e);
            }
            case "PRINTCH": {

                lex.next();
                Exp e = Exp();
                //System.out.println("Parsing PRINTCH statement"); debugging
                //System.out.println("Parsed expression: " + e); debugging
                lex.eat("SEMIC");
                return new StmPrintChar(e);
            }
            case "NEWLINE": {
                lex.next();
                lex.eat("SEMIC");
                return new StmNewline();
            }

            case "SWITCH": {
                lex.next();
                lex.eat("LBR");
                Exp e = Exp();
                lex.eat("RBR");
                lex.eat("LCBR");
                List<StmSwitch.Case> cases = new ArrayList<>();
                while (lex.tok().isType("CASE")) {
                    cases.add(Case());
                }
                lex.eat("DEFAULT");
                lex.eat("COLON");
                Stm defaultBlock = Stm();
                lex.eat("RCBR");
                return new StmSwitch(e, defaultBlock, cases);
            }


            default:
                throw new ParseException(lex.tok(), "LCBR", "ID", "IF", "WHILE", "PRINT", "PRINTLN", "PRINTCH", "NEWLINE", "SWITCH", "RETURN");
        }

        //Extend the parser - part 2 coursework
        // pass all test in the parser test. for LPL-B.snbnf


        // for StmIdFactor
    }



    // create the method def






    // StmIdFactor -> LBR Actuals RBR SEMIC | ASSIGN Exp SEMIC
    private Stm StmIdFactor(String id) {
        if (lex.tok().isType("LBR")) {
            lex.eat("LBR");
            List<Exp> actuals = actuals();
            lex.eat("RBR");
            lex.eat("SEMIC");
            return new StmMethodCall(id, actuals);
        } else {
            List<Exp> indices = Indexer();  // Handle Indexer*
            if (lex.tok().isType("ASSIGN")) {
                lex.eat("ASSIGN");
                Exp e = Exp();
                lex.eat("SEMIC");
                if (indices.isEmpty()) {
                    return new StmAssign(id, e);  // Scalar assignment
                } else {
                    return new StmAssignArray(id, indices, e);  // Array element assignment
                }
            } else {
                throw new ParseException(lex.tok(), "LBR", "ASSIGN");
            }
        }
    }


    private List<Exp> Indexer() {
        List<Exp> indices = new ArrayList<>();
        while (lex.tok().isType("LSQBR")) {
            lex.eat("LSQBR");
            Exp index = Exp();
            lex.eat("RSQBR");
            indices.add(index);
        }
        return indices;
    }

    //Actuals -> Exp AnotherActual*
    //Actuals ->

    //AnotherActual -> COMMA Exp
    private List<Exp> actuals(){
        List<Exp> actuals = new ArrayList<>();
        if(!lex.tok().isType("RBR")) {  // right bracket = empty bracket
            actuals.add(Exp());
            while (lex.tok().isType("COMMA")) { //anotherACTUAL
                lex.eat("COMMA");
                actuals.add(Exp());
            }

        }
        return actuals;
    }



    private Stm StmReturnFactor() {
        if (lex.tok().isType("SEMIC")) {
            lex.eat("SEMIC");
            return new StmReturn(null);
        } else {
            Exp e = Exp();
            lex.eat("SEMIC");
            return new StmReturn(e);
        }
    }


    private Exp SimpleIDFactor(String id) {
        if (lex.tok().isType("LBR")) {
            lex.eat("LBR");
            List<Exp> actuals = actuals();
            lex.eat("RBR");
            return new ExpFunCall(id, actuals);
        } else {
            List<Exp> indices = Indexer();
            if (lex.tok().isType("DOT")) {
                lex.eat("DOT");
                lex.eat("LENGTH");
                return new ExpArrayLength(id);
            } else if (indices.isEmpty()) {
                return new ExpVar(id);
            } else {
                return new ExpAccessArray(id, indices);
            }
        }
    }




    private List<VarDecl> Formals() {
        List<VarDecl> formals = new ArrayList<>();
        if (!lex.tok().isType("RBR")) {  // Not empty
            Type type = Type();
            String id = lex.tok().image;
            lex.eat("ID");
            formals.add(new VarDecl(type, id));
            while (lex.tok().isType("COMMA")) {  // AnotherFormal*
                lex.eat("COMMA");
                type = Type();
                id = lex.tok().image;
                lex.eat("ID");
                formals.add(new VarDecl(type, id));
            }
        }
        return formals;
    }




    private List<VarDecl> NonFormalVarDecls() {
        List<VarDecl> decls = new LinkedList<>();
        while (lex.tok().isType("INT_TYPE")) {
            Type type = Type();
            String id = lex.tok().image;
            lex.eat("ID");
            lex.eat("SEMIC");
            decls.add(new VarDecl(type, id));
        }
        return decls;
    }

    private MethodDef FunOrProcDef(){
        Type returnType = null;
        boolean isReturnFunction;
        if(lex.tok().isType("FUN")){
            lex.eat("FUN");
            isReturnFunction = true;
            returnType = Type();
        } else {
            lex.eat("PROC");
            isReturnFunction = false;
        }
        // function has int type
        // procedure is void -> goes straight to the function.
        // create the Method
        String methodName = lex.tok().image;
        lex.eat("ID");
        lex.eat("LBR");
        List<VarDecl> formals = Formals();
        lex.eat("RBR");
        lex.eat("LCBR");
        List<VarDecl> localvar = NonFormalVarDecls();
        List<Stm> body = new ArrayList<>();

        while(!lex.tok().isType("RCBR")) {
            body.add(Stm());
        }
        lex.eat("RCBR");
        return new MethodDef(isReturnFunction, returnType, methodName, formals, localvar, body);
    }


    //create new array
    private Exp NewArrayExp() {
        if (lex.tok().isType("INT_TYPE")) {
            lex.next();
            lex.eat("LSQBR");
            Exp size = Exp();
            lex.eat("RSQBR");
            List<Integer> extraDims = new ArrayList<>();
            while (lex.tok().isType("LSQBR")) {  // Handle ArraySpec*
                lex.eat("LSQBR");
                lex.eat("RSQBR");
                extraDims.add(0);
            }
            int totalDims = 1 + extraDims.size();
            return new ExpNewArray(new TypeInt(), size, totalDims);
        } else {
            throw new ParseException(lex.tok(), "INT_TYPE");
        }
    }



        /**
         * Parse and pretty-print an LPL source file specified
         * by a command line argument.
         * @param args command-line arguments
         * @throws ParseException if the source file contains syntax errors
         * @throws IOException
         */
        public static void main (String[]args) throws IOException {
            if (args.length != 1) {
                System.err.println("Usage: parse.LPLParser <source-file>");
                System.exit(1);
            }
            LPLParser parser = new LPLParser();
            Program program = parser.parse(args[0]);
            System.out.println(program);

        }
    }
