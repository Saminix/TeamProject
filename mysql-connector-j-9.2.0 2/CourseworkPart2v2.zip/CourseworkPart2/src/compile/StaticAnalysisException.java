package compile;

public class StaticAnalysisException extends RuntimeException {
    public StaticAnalysisException(String message) {
        super(message);
    }
}
