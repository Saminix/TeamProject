package compile;

import ast.MethodDef;
import ast.Program;
import ast.Type;
import ast.VarDecl;

import java.util.*;

public class SymbolTable {
    private final Map<String, Type> globals;
    private final Map<String, MethodEntry> methods;
    public Map<String, VarEntry> locals;
    public boolean inMethodScope;
    private int freshNameCounter;

    public static class MethodEntry {
        private final String label;
        private final int paramCount;
        private final boolean isFunction;
        private final Type returnType;

        public MethodEntry(String label, int paramCount, boolean isFunction, Type returnType) {
            this.label = label;
            this.paramCount = paramCount;
            this.isFunction = isFunction;
            this.returnType = returnType;
        }

        public String getLabel() { return label; }
        public int getParamCount() { return paramCount; }
        public boolean isFunction() { return isFunction; }
        public Type getReturnType() { return returnType; }
    }

    private static class VarEntry {
        private final Type type;
        private final int offset;

        public VarEntry(Type type, int offset) {
            this.type = type;
            this.offset = offset;
        }

        public Type getType() { return type; }
        public int getOffset() { return offset; }
    }

    public SymbolTable(Program program) {
        this.freshNameCounter = 0;
        this.globals = new HashMap<>();
        this.methods = new HashMap<>();
        this.locals = null;
        this.inMethodScope = false;
        for (VarDecl decl : program.varDecls) {
            if (globals.put(decl.name, decl.type) != null) {
                throw new StaticAnalysisException("Duplicate global variable: " + decl.name);
            }
        }
        List<MethodDef> methodDefs = Program.getMethods();
        System.out.println("SymbolTable methods: " + methodDefs.size());
        for (MethodDef method : methodDefs) {
            System.out.println("Registering: " + method.name);
            String label = "$_" + method.name;
            if (methods.put(method.name, new MethodEntry(label, method.formals.size(),
                    method.isFunction, method.returnType)) != null) {
                throw new StaticAnalysisException("Duplicate method: " + method.name);
            }
        }
    }

    public void enterMethodScope(List<VarDecl> formals) {
        inMethodScope = true;
        locals = new HashMap<>();
        int offset = 2; // After return address and saved FP
        for (VarDecl param : formals) {
            locals.put(param.name, new VarEntry(param.type, offset++));
        }
    }

    public int addLocal(String name, Type type) {
        if (!inMethodScope) {
            throw new IllegalStateException("Cannot add local outside method scope");
        }
        int offset = locals.size() + 2;
        if (locals.put(name, new VarEntry(type, offset)) != null) {
            throw new StaticAnalysisException("Duplicate local variable: " + name);
        }
        return offset;
    }

    public void exitMethodScope() {
        inMethodScope = false;
        locals = null;
    }

    public Type getVarType(String name) {
        if (inMethodScope && locals != null) {
            VarEntry local = locals.get(name);
            if (local != null) {
                return local.getType();
            }
        }
        Type global = globals.get(name);
        if (global == null) {
            throw new StaticAnalysisException("Undeclared variable: " + name);
        }
        return global;
    }

    public int getVarOffset(String name) {
        if (inMethodScope && locals != null) {
            VarEntry local = locals.get(name);
            if (local != null) {
                return local.getOffset();
            }
        }
        return -1;
    }

    public List<String> lookupVarAddress(String name) {
        List<String> instructions = new ArrayList<>();
        if (inMethodScope && locals != null) {
            VarEntry local = locals.get(name);
            if (local != null) {
                System.out.println("Found " + name + " at offset " + local.getOffset());
                instructions.add("get_fp");
                instructions.add("push " + local.getOffset());
                instructions.add("add");
                return instructions;
            }
            System.out.println(name + " not in locals");
        }
        Type global = globals.get(name);
        if (global != null) {
            System.out.println(name + " is global");
            instructions.add("push " + makeVarLabel(name));
            return instructions;
        }
        throw new StaticAnalysisException("Undeclared variable: " + name);
    }

    public boolean isGlobal(String name) {
        return globals.containsKey(name);
    }

    public MethodEntry lookupMethod(String name) {
        return methods.get(name);
    }

    public Set<String> globalNames() {
        return new HashSet<>(globals.keySet());
    }

    public static String makeVarLabel(String sourceName) {
        return "$W_" + sourceName;
    }

    public String freshLabel(String prefix) {
        return "$$_" + prefix + "_" + (freshNameCounter++);
    }
}