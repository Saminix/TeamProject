package ast;

import compile.SymbolTable;

import java.util.List;

public class StmAssignArray extends Stm{
    private final String id;
    private final List<Exp> indices;
    private final Exp value;

    public StmAssignArray(String id, List<Exp> indices, Exp value) {
        this.id = id;
        this.indices = indices;
        this.value = value;

    }

    @Override
    public void compile(SymbolTable st) {
        Type type = st.getVarType(id);
        if (!(type instanceof TypeArray)) {
            throw new RuntimeException("Variable " + id + " is not an array");
        }
        if (indices.size() > ((TypeArray) type).getSize()) {
            throw new RuntimeException("Too many indices for array " + id);
        }
        if (st.isGlobal(id)) {
            emit("push " + st.lookupVarAddress(id));  // Global label
        } else {
            emit(st.lookupVarAddress(id));            // FP + offset for local
        }
        emit("load");
        for (Exp index : indices) {
            index.compile(st);
            emit("push 4");
            emit("mul");
            emit("add");
        }
        value.compile(st);
        emit("store");              // Add to running address
        }

        // Step 3: Compile the value to assign


    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) { return visitor.visit(this); }
}
