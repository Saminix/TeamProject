package ast;

import compile.SymbolTable;

public class StmReturn extends Stm{
    public final Exp expression;


    // use the ret method

    public StmReturn(Exp expression) {
        this.expression = expression;

    }

    @Override
    public void compile(SymbolTable st) {
        if (expression != null) {
            expression.compile(st); // Push result onto the stack
            emit("str_ret");        // Store return value (SSM convention, if supported)
            emit("ret");            // Return with value
        } else {
            // Procedure return: No value needed
            emit("ret");
        }
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) { return visitor.visit(this); }
}
