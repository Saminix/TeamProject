package ast;

import compile.SymbolTable;

import java.util.Collections;
import java.util.List;

public class Program extends AST {
    public final List<VarDecl> varDecls;
    public final List<Stm> body;
    private static List<MethodDef> methods = Collections.emptyList();

    public Program(List<VarDecl> varDecls, List<Stm> body) {
        this.varDecls = Collections.unmodifiableList(varDecls);
        this.body = Collections.unmodifiableList(body);
    }

    public static void setMethods(List<MethodDef> methodDefs) {
        methods = Collections.unmodifiableList(methodDefs);
    }

    public static List<MethodDef> getMethods() {
        return methods;
    }

    public void compile() {
        SymbolTable st = new SymbolTable(this);
        if (methods.isEmpty() && varDecls.stream().noneMatch(vd -> vd.type instanceof TypeArray)) {
            // Part 1 style for compileA
            for (Stm stm : body) {
                stm.compile(st);
            }
            emit("halt");
            emit(".data");
            for (String varName : st.globalNames()) {
                emit(st.makeVarLabel(varName) + ": 0");
            }
        } else {
            // Part 2 style
            emit("jumpi $main");
            emit("$main:");
            for (String varName : st.globalNames()) {
                emit("push 0");
                emit("storei " + st.makeVarLabel(varName));
            }
            if (!methods.isEmpty() || varDecls.stream().anyMatch(vd -> vd.type instanceof TypeArray)) {
                int globalSize = varDecls.size() * 4;
                emit("get_dp");
                emit("push " + globalSize);
                emit("add");
                emit("push $heap_ptr");
                emit("store");
            }
            for (Stm stm : body) {
                stm.compile(st);
            }
            emit("halt");
            for (MethodDef method : methods) {
                method.compile(st);
            }
            for (String varName : st.globalNames()) {
                emit(st.makeVarLabel(varName) + ":");
            }
            if (!methods.isEmpty() || varDecls.stream().anyMatch(vd -> vd.type instanceof TypeArray)) {
                emit("$heap_ptr:");
            }
        }
    }
    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}