package ast;

import compile.SymbolTable;

import java.util.List;

/**
 * Represents a method definition (function or procedure) in LPL.
 */
public class MethodDef extends Stm{
    public final boolean isFunction;      // check if it's a  FUN, or false for a PROC
    public final Type returnType;         // Return type (null for procedures)

    public final String name;              // Method name
    public final List<VarDecl> formals;   // Formal parameters
    private final List<VarDecl> locals;    // Local variables
    private final List<Stm> body;          // Body statements

    /**
     * Constructs a method definition.
     *
     * @param isFunction True = function, false = procedure.
     * @param returnType Return type (null for procedures).
     * @param name       Method name.
     * @param formals    List of parameters.
     * @param locals     List of local variables.
     * @param body       List of statements.
     */
    public MethodDef(boolean isFunction, Type returnType, String name,
                     List<VarDecl> formals, List<VarDecl> locals, List<Stm> body) {
        //add to the constructor :
        this.isFunction = isFunction;
        this.returnType = returnType; // (Type) = IntType
        this.name = name;            // method name
        this.formals = formals;
        this.locals = locals;
        this.body = body;
    }

    /**
     * Compiles the method into SSM assembly code.
     *
     * @param st The symbol table for scope management.
     */
    @Override
    public void compile(SymbolTable st) {
        String label = "$_" + name;
        emit(label + ":");
        st.enterMethodScope(formals); // Set up parameter offsets
        // Allocate space for locals
        if (!locals.isEmpty()) {
            emit("salloc " + locals.size());
            for (VarDecl local : locals) {
                st.addLocal(local.name, local.type);
            }
        }
        // Compile body
        for (Stm stm : body) {
            stm.compile(st);
        }
        // Implicit return if no explicit return statement
        if (!endsWithReturn(body)) {
            if (isFunction) {
                emit("push 0"); // Default return value for functions
                emit("str_ret"); // Store return value (if supported)
            }
            emit("ret");
        }
        st.exitMethodScope();
    }

    private boolean endsWithReturn(List<Stm> body) {
        return !body.isEmpty() && body.get(body.size() - 1) instanceof StmReturn;
    }

    /**
     * Accepts a visitor for traversing this method definition.
     *
     * @param visitor The visitor to process this node.
     * @return The result of the visitor's processing.
     */
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }


}