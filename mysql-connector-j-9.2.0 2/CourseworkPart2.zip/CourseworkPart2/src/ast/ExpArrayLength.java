package ast;

import compile.SymbolTable;

public class ExpArrayLength extends Exp{
    private final String id;

    public ExpArrayLength(String id) {
      this.id  = id;
    }

    @Override
    public void compile(SymbolTable st) {
        Type type = st.getVarType(id);
        if (!(type instanceof TypeArray)) {
            throw new RuntimeException("Variable " + id + " is not an array");
        }
        if (st.isGlobal(id)) {
            emit("push " + st.lookupVarAddress(id));
        } else {
            emit(st.lookupVarAddress(id));
        }
        emit("load");
        emit("load");
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) { return visitor.visit(this); }

}

