package ast;


import compile.SymbolTable;

import java.util.List;

// creation of a method call statement
// parameter value passed to the function
// total number of parameters passing
public class StmMethodCall extends Stm{

    // list of all parameters passed to the method
    public final List<Exp> actuals;
   // name of method being called
    public final String id;

    public StmMethodCall(String id, List<Exp> actuals) {
        this.actuals = actuals;
        this.id = id;
    }

    @Override
    public void compile(SymbolTable st) {
        SymbolTable.MethodEntry method = st.lookupMethod(id);
        if (method == null) {
            throw new RuntimeException("Undefined method: " + id);
        }
        if (method.getParamCount() != actuals.size()) {
            throw new RuntimeException("Method " + id + " expects " + method.getParamCount() +
                    " parameters but got " + actuals.size());
        }
        // Push arguments onto the stack
        for (Exp arg : actuals) {
            arg.compile(st);
        }
        // Push number of arguments
        emit("push " + actuals.size());
        // Call the method
        emit("calli " + method.getLabel());
        // For functions, discard return value since this is a statement
        if (method.isFunction()) {
            emit("pop");
        }
    }

    @Override
    public <T> T accept(ast.util.Visitor<T> visitor) {
        return visitor.visit(this);
    }
}



