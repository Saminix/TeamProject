package ast;

import compile.SymbolTable;

import java.util.List;

public class ExpFunCall extends Exp {
    // calling a function
    public final String id;
    public final List<Exp> actuals;


    public ExpFunCall(String id, List<Exp> actuals) {

        // push the parameters, call function and leave the return value on the stack.
        this.actuals = actuals;
        this.id = id;
    }

    @Override
    public void compile(SymbolTable st) {
        SymbolTable.MethodEntry method = st.lookupMethod(id);
        if (method == null) {
            throw new RuntimeException("Undefined function: " + id);
        }
        if (!method.isFunction()) {
            throw new RuntimeException("Method " + id + " is a procedure, not a function; it does not return a value");
        }
        if (method.getParamCount() != actuals.size()) {
            throw new RuntimeException("Function " + id + " expects " + method.getParamCount() +
                    " parameters but got " + actuals.size());
        }
        // Push arguments
        for (Exp param : actuals) {
            param.compile(st);
        }
        // Push number of arguments
        emit("push " + actuals.size());
        // Call function, leave return value on stack
        emit("calli " + method.getLabel());
    }

        @Override
        public <T > T accept(ast.util.Visitor < T > visitor) {
            return visitor.visit(this);
        }








    }
