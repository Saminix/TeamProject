package compile;

import ast.MethodDef;
import ast.Program;
import ast.Type;
import ast.VarDecl;

import java.util.*;

/**
 * A symbol table for tracking variables and methods in an LPL program.
 * Supports global variables, method definitions, and local scopes (parameters and locals)
 * for compiling LPL-B programs into SSM assembly code.
 */
public class SymbolTable {
    // Stores global variables: name -> type
    private final Map<String, Type> globals;

    // Stores method definitions: name -> MethodEntry
    private final Map<String, MethodEntry> methods;

    // Stores local variables/parameters in the current method scope: name -> VarEntry
    private Map<String, VarEntry> locals;

    // Indicates whether we're compiling within a method scope
    private boolean inMethodScope;

    // Counter for generating unique labels
    private int freshNameCounter;

    /**
     * Represents a method definition in the symbol table.
     */
    public static class MethodEntry {
        private final String label;       // SSM label (e.g., "$_computeArea")
        private final int paramCount;     // Number of parameters
        private final boolean isFunction; // True if FUN, false if PROC
        private final Type returnType;    // Return type (null for procedures)

        public MethodEntry(String label, int paramCount, boolean isFunction, Type returnType) {
            this.label = label;
            this.paramCount = paramCount;
            this.isFunction = isFunction;
            this.returnType = returnType;
        }

        public String getLabel() { return label; }
        public int getParamCount() { return paramCount; }
        public boolean isFunction() { return isFunction; }
        public Type getReturnType() { return returnType; }
    }

    /**
     * Represents a variable (parameter or local) within a method scope.
     */
    private static class VarEntry {
        private final Type type;    // The variable's type (e.g., TypeInt)
        private final int offset;   // Offset from FP for locals/parameters, -1 for globals

        public VarEntry(Type type, int offset) {
            this.type = type;
            this.offset = offset;
        }

        public Type getType() { return type; }
        public int getOffset() { return offset; }
    }

    /**
     * Initializes a new symbol table for the given LPL program.
     */
    public SymbolTable(Program program) {
        this.freshNameCounter = 0;
        this.globals = new HashMap<>();
        this.methods = new HashMap<>();
        this.locals = null;
        this.inMethodScope = false;

        // Register global variables
        for (VarDecl decl : program.varDecls) {
            if (globals.put(decl.name, decl.type) != null) {
                throw new StaticAnalysisException("Duplicate global variable: " + decl.name);
            }
        }

        // Register method definitions from Program’s static storage
        List<MethodDef> methodDefs = Program.getMethods(); // Assume a getter; adjust as needed
        for (MethodDef method : methodDefs) {
            String label = "$_" + method.name;
            if (methods.put(method.name, new MethodEntry(label, method.formals.size(),
                    method.isFunction, method.returnType)) != null) {
                throw new StaticAnalysisException("Duplicate method: " + method.name);
            }
        }
    }

    // Methods below remain largely unchanged but are included for completeness

    /**
     * Enters a method scope, initializing the local scope with parameters.
     */
    public void enterMethodScope(List<VarDecl> formals) {
        inMethodScope = true;
        locals = new HashMap<>();
        int offset = 2;  // After return address and saved FP
        for (VarDecl param : formals) {
            locals.put(param.name, new VarEntry(param.type, offset++));
        }
    }

    /**
     * Adds a local variable to the current method scope.
     */
    public int addLocal(String name, Type type) {
        if (!inMethodScope) {
            throw new IllegalStateException("Cannot add local outside method scope");
        }
        int offset = locals.size() + 2; // Offset after params
        if (locals.put(name, new VarEntry(type, offset)) != null) {
            throw new StaticAnalysisException("Duplicate local variable: " + name);
        }
        return offset;
    }

    /**
     * Exits the current method scope.
     */
    public void exitMethodScope() {
        inMethodScope = false;
        locals = null;
    }

    /**
     * Retrieves the type of a variable, checking local scope first if in a method.
     */
    public Type getVarType(String name) {
        if (inMethodScope && locals != null) {
            VarEntry local = locals.get(name);
            if (local != null) {
                return local.getType();
            }
        }
        Type global = globals.get(name);
        if (global == null) {
            throw new StaticAnalysisException("Undeclared variable: " + name);
        }
        return global;
    }

    /**
     * Gets the offset of a variable relative to the Frame Pointer (FP).
     */
    public int getVarOffset(String name) {
        if (inMethodScope && locals != null) {
            VarEntry local = locals.get(name);
            if (local != null) {
                return local.getOffset();
            }
        }
        return -1;  // Indicates the variable is global
    }

    /**
     * Looks up a variable and returns its address (label for globals, offset-based for locals).
     */
    public String lookupVarAddress(String name) {
        if (inMethodScope && locals != null) {
            VarEntry local = locals.get(name);
            if (local != null) {
                return "get_fp " + local.getOffset() + " add";
            }
        }
        Type global = globals.get(name);
        if (global != null) {
            return makeVarLabel(name);
        }
        throw new StaticAnalysisException("Undeclared variable: " + name);
    }

    /**
     * Checks if a variable is global.
     */
    public boolean isGlobal(String name) {
        return globals.containsKey(name);
    }

    /**
     * Looks up a method by its name.
     */
    public MethodEntry lookupMethod(String name) {
        return methods.get(name);
    }

    /**
     * Returns a set of all global variable names.
     */
    public Set<String> globalNames() {
        return new HashSet<>(globals.keySet());
    }

    /**
     * Transforms an LPL variable name into an SSM label for global variables.
     */
    public static String makeVarLabel(String sourceName) {
        return "$W_" + sourceName;
    }

    /**
     * Generates a fresh label for control flow.
     */
    public String freshLabel(String prefix) {
        return "$$_" + prefix + "_" + (freshNameCounter++);
    }
}